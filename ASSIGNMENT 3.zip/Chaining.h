#ifndef CHAINING_H
#define CHAINING_H

#include "BaseClass.h"
#include <iostream>
#include <vector>
using namespace std;

class Chaining : public BaseClass {
public:
    Chaining(){
        bankStorage2d = std:: vector<std:: vector<Account>>(capacity);
    }
    void createAccount(string id, int count) override;
    vector<int> getTopK(int k) override;
    int getBalance(string id) override;
    void addTransaction(string id, int count) override;
    bool doesExist(string id) override;
    bool deleteAccount(string id) override;
    int databaseSize() override;
    int hash(string id) override;
    

private : 
    vector<Account> VectorOfBalances;
    int size = 0;
    long long ModularExponentiation(long long x, long long n, long long m);
    
    void mergeSort(vector<Account>& acc, int l , int r) ;
    void merge(vector<Account>& acc, int l , int m , int r) ;
    int capacity=100003;
  

    
    // Other data members and functions specific to Chaining
};


#endif // CHAINING_H 
