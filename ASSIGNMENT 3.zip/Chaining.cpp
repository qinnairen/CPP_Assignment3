#include "Chaining.h"
using namespace std;

void Chaining::merge(vector<Account>& acc, int l , int m , int r) {
    int n1 = m - l + 1;
    int n2 = r - m;

    vector<Account> leftVec(n1);
    vector<Account> rightVec(n2);

    for (int i = 0; i < n1; i++) {
        leftVec[i] = acc[l + i];
    }
    for (int j = 0; j < n2; j++) {
        rightVec[j] = acc[m + 1 + j];
    }

    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {
        if (leftVec[i].balance <= rightVec[j].balance) {
            acc[k] = leftVec[i];
            i++;
        } else {
            acc[k] = rightVec[j];
            j++;
        };
        k++;
    }

    while (i < n1) {
        acc[k] = leftVec[i];
        i++;
        k++;
    }

    while (j < n2) {
        acc[k] = rightVec[j];
        j++;
        k++;
    }
    return ;
}


void Chaining::mergeSort(vector<Account>& acc, int l , int r) {
    if (l < r) {
        int m = (r+l) / 2;
        mergeSort(acc, l, m);
        mergeSort(acc, m + 1, r);
        merge(acc, l, m, r);
    }
    return ;
}


void Chaining::createAccount(string id, int count) {
    size = size +1 ; 
    struct Account a;
    a.id = id;
    a.balance = count;
    int hashValue = hash(id);
    bankStorage2d[hashValue].push_back(a);
    VectorOfBalances.push_back(a);
    mergeSort(VectorOfBalances, 0, size -1);
    cout<<VectorOfBalances[0].balance<<endl;
}
    
vector<int> Chaining::getTopK(int k) {
    vector<int> topK ;
    if (k>size) {
        for (int i=size-1 ; i>=0 ; i--) {
            topK.push_back(VectorOfBalances[i].balance);
        }
    }
    else {
    for (int i = size -1  ; i>(size-k-1); i--) {
        topK.push_back(VectorOfBalances[i].balance);
    }
    }
    return topK; 
}


int Chaining::getBalance(string id) {
    int hashValue = hash(id);
    if (doesExist(id)==false) {
        return -1;
    }
    // int s=bankStorage2d[hashValue].size();
    // for (int i =0 ; i< s; i++){
    for (int i =0 ; i< bankStorage2d[hashValue].size(); i++) {
        if (bankStorage2d[hashValue][i].id==id) {
            int b = bankStorage2d[hashValue][i].balance;
            return b;
}
    }
    return -1;
}

void Chaining::addTransaction(string id, int count) {
    int hashValue = hash(id);
    if (doesExist(id)==false) {
        createAccount(id, count);
    }
        // int s=bankStorage2d[hashValue].size();
        // for (int i =0 ; i< s; i++){
        for (int i=0;i<bankStorage2d[hashValue].size();i++) {
        if (bankStorage2d[hashValue][i].id==id) {
        bankStorage2d[hashValue][i].balance = bankStorage2d[hashValue][i].balance + count ;
    }
    }
        
    for (int i = 0; i <size; i++) {
        if (VectorOfBalances[i].id==id) {
            VectorOfBalances[i].balance = VectorOfBalances[i].balance + count ; 
        }
        mergeSort(VectorOfBalances, 0 , size - 1);
    }
    return ;

}
    

 bool Chaining::doesExist(string id) {
    int hashValue = hash(id);
    int l = bankStorage2d[hashValue].size();
    for (int i=0; i<l;i++) {
        if (id ==bankStorage2d[hashValue][i].id ) {
            return true ;
        }
    }
    return false; 
}

bool Chaining::deleteAccount(string id) {
    int hashValue = hash(id);
    if (doesExist(id)==false) {
        return false;
    }
    // int s=bankStorage2d[hashValue].size();
    // for (int i =0 ; i< s; i++){
    for (int i=0;i<bankStorage2d[hashValue].size();i++) {
        if (bankStorage2d[hashValue][i].id==id) {
        bankStorage2d[hashValue][i].id = "Deleted Account";
        bankStorage2d[hashValue][i].balance = 0;
        mergeSort(VectorOfBalances, 0 , size - 1);
        return true;
    }
    }
    return false;
}


int Chaining::databaseSize() {
    return size; 
}

int Chaining::hash(string id) { 
    const long long p= 13;
    const long long m=19997;
    long long hashValue = 0;
    long long pow = 1;
    string const& s = id;
    for (char c : s) {
        int z = int(c);        
        long long k = static_cast<long long>(z);
        hashValue = (hashValue%m + ModularExponentiation(k,pow,m));
        pow = pow+1 ;
    }
    cout<<hashValue<<endl;
    return hashValue;
    }

long long Chaining::ModularExponentiation(long long a,long long n, long long m){
    if (m==1) {
        return 0;
    }
    long long result = 1;
    while (n >0) {
        if (n%2 == 1) {
            result = (result*a)%m;
        }
        else {
            result = (a*a)%m;
        }
        n=n/2;
    }
    return result; 
}

int main() {
    Chaining a;
    a.createAccount("AKARSH", 20000);
    cout<<a.getBalance("AKARSH")<<endl;
    cout<<a.databaseSize()<<endl;
}
