#ifndef BASECLASS_H
#define BASECLASS_H

#include <string>
#include <vector>
using namespace std;
struct Account {
    string id;
    int balance;
};

class BaseClass {
public:
    virtual void createAccount(string id, int count) = 0;
    virtual vector<int> getTopK(int k) = 0;
    virtual int getBalance(string id) = 0;
    virtual void addTransaction(string id, int count) = 0;
    virtual bool doesExist(string id) = 0;
    virtual bool deleteAccount(string id) = 0;
    virtual int databaseSize() = 0;
    virtual int hash(string id) = 0;

    vector<Account> bankStorage1d;
    vector<vector<Account>> bankStorage2d;
    
};

#endif // BASECLASS_H
