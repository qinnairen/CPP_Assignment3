#include "QuadraticProbing.h"
using namespace std;

void QuadraticProbing::merge(vector<Account>& acc, int l , int m , int r) {
    int n1 = m - l + 1;
    int n2 = r - m;

    vector<Account> leftVec(n1);
    vector<Account> rightVec(n2);

    for (int i = 0; i < n1; i++) {
        leftVec[i] = acc[l + i];
    }
    for (int j = 0; j < n2; j++) {
        rightVec[j] = acc[m + 1 + j];
    }

    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {
        if (leftVec[i].balance <= rightVec[j].balance) {
            acc[k] = leftVec[i];
            i++;
        } else {
            acc[k] = rightVec[j];
            j++;
        };
        k++;
    }

    while (i < n1) {
        acc[k] = leftVec[i];
        i++;
        k++;
    }

    while (j < n2) {
        acc[k] = rightVec[j];
        j++;
        k++;
    }
    return ;
}


void QuadraticProbing::mergeSort(vector<Account>& acc, int l , int r) {
    if (l < r) {
        int m = (r+l) / 2;
        mergeSort(acc, l, m);
        mergeSort(acc, m + 1, r);
        merge(acc, l, m, r);
    }
    return ;
}

QuadraticProbing::QuadraticProbing() {
    for (int i = 0; i<302429;i++) {
        struct Account a;
        a.id = "";
        a.balance = 0;
        bankStorage1d.push_back(a);
    }

}


void QuadraticProbing::createAccount(string id, int count) {
    int IniSize = size;
    size = size+1;
    struct Account a ; 
    int NumOfAccounts ;
    a.id = id;
    a.balance = count;
    int hashValue = hash(id);
    int i = 1 ;
    while (bankStorage1d[hashValue].id != "" && bankStorage1d[hashValue].id != "Deleted Account") {
        hashValue = (hashValue + i*i)%302429 ;
        i = i+1 ; 
    }
    bankStorage1d[hashValue]=a;
    if (IniSize==0) {
        VectorOfBalances.push_back(a);
        mergeSort(VectorOfBalances, 0, size -1);
    }
    else {
        VectorOfBalances.push_back(a);
        mergeSort(VectorOfBalances, 0, size -1);
    }
}

vector<int> QuadraticProbing::getTopK(int k) {
   vector<int> topK;
    if (k>size) {
        for (int i=size-1 ; i>=0 ; i--) {
            topK.push_back(VectorOfBalances[i].balance);
        }
    }
    else {
    for (int i = size -1  ; i>=(size-k-1); i--) {
        topK.push_back(VectorOfBalances[i].balance);
    }
    }
    return topK; 
}

int QuadraticProbing::getBalance(std::string id) {
    int hashValue = hash(id);
    if (doesExist(id)==false) {
        return -1;
    }
    int i = 1;
    while (bankStorage1d[hashValue].id!=id) {
    hashValue = hashValue +i ;
    hashValue = hashValue %302429 ;
    i = i+1 ;
    }
    
    int b = bankStorage1d[hashValue].balance;
    return b;
    }


void QuadraticProbing::addTransaction(std::string id, int count) {
    int hashValue = hash(id);
    if (doesExist(id)==false) {
        createAccount(id, count);
        return ; 
    }
    int i = 1;
        while (bankStorage1d[hashValue].id!=id) {
            hashValue = hashValue +i;
            hashValue = hashValue %200003 ;
            i = i+1;
            }
        bankStorage1d[hashValue].balance = bankStorage1d[hashValue].balance + count ;
    
    for (int i = 0; i <size; i++) {
        if (VectorOfBalances[i].id==id) {
            VectorOfBalances[i].balance = VectorOfBalances[i].balance + count ; 
        }
        mergeSort(VectorOfBalances, 0 , size - 1);
    }
    return ;
}

bool QuadraticProbing::doesExist(std::string id) {
    int hashValue = hash(id);
    if (id==bankStorage1d[hashValue].id) {
        return true;
    }
    else {
        int i = 1; 
        int a = hashValue;
        while (bankStorage1d[hashValue].id!=id) {
            hashValue  = hashValue +i ; 
            hashValue = hashValue %200003;
            i = i +1 ;
            if (hashValue=a) {
                return false;
            }
        }
        return true;
    }
}

bool QuadraticProbing::deleteAccount(std::string id) {
    int hashValue = hash(id);
    if (doesExist(id)==false) {
        return false;
    }
        int i = 1; 
        while (bankStorage1d[hashValue].id!=id) {
            hashValue  = hashValue +i ; 
            hashValue = hashValue % 200003;
            i = i +1 ; 
        }
        bankStorage1d[hashValue].id = "Deleted Account";
        bankStorage1d[hashValue].balance = 0;
        mergeSort(VectorOfBalances, 0 , size - 1);
        return true;
    }

    
int QuadraticProbing::databaseSize() {
    return size;
}

int QuadraticProbing::hash(string id) { 
    const long long p= 13;
    const long long m=200003;
    long long hashValue = 0;
    long long pow = 1;
    string const& s = id;
    for (char c : s) {
        int z = int(c);        
        long long k = static_cast<long long>(z);
        hashValue = (hashValue%m + ModularExponentiation(k,pow,m));
        pow = pow+1 ;
    }
    cout<<hashValue<<endl;
    return hashValue;
    }

long long QuadraticProbing::ModularExponentiation(long long a,long long n, long long m){
    if (m==1) {
        return 0;
    }
    long long result = 1;
    while (n >0) {
        if (n%2 == 1) {
            result = (result*a)%m;
        }
        else {
            result = (a*a)%m;
        }
        n=n/2;
    }
    return result; 
}

